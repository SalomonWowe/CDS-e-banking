<html>
<title>Online Banking System</title>
<head>
   <link rel="stylesheet" type="text/css" href="css/index.css">
   <link rel="shortcut icon" href="img/logo.png">
    </head>
 
<body>
<?php include'header.php'?>
<div class="index_container">
    <div class="slider">
    <div class="slideimg">
    <img src="img/CDS1.jpg" alt="">
    <img src="img/credit sco.png" alt="">
    <img src="img/CDS1.jpg" alt="">
    <img src="img/CDS1.jpg" alt="">
        </div>
    </div><br>
    <!-- <div class="newsroom">
        
        <marquee class="marquee_news" scrolldelay="20"><p class="newsfeed"><span>Your bank may charge you for closing a bank account. 
        Bank also charges you when you close your account within a particular time period.</span><span>SBI cuts deposit rates; PPF to fetch lower interest rate. </span><span>No, it is not mandatory to link your bank account with CITIZENSHIP card</span></p></marquee>
    </div><br><br> -->
   

    
<div class="news_events">
    <h4>Tips | Updates | Events</h4><br>
        <ul>
            <p>Tout d'abord, ouvrez un compte. Ensuite, demandez une carte de débit pour obtenir plus de détails.
 </p><br>
<p>Et enfin, procédez à l'inscription à la banque par Internet pour créer votre compte bancaire par Internet.
</p>
            <br>
        </ul>
    </div>
    

    <div class="online_services">
        <h4>Online Services</h4>
        <ul>
            <a href="customer_reg_form.php"><li>Ouvrir un compte</li></a>
            <a href="debit_card_form.php"><li>Demande  carte  débit</li></a><br>
            <a href="#" id="ebanking" ><li><div class="ebanking">Internet Banking
                <div class = "ebanking_options">
                <ul>
                    <a href="customer_login.php"><li>Login </li></a>
                    <a href="ebanking_reg_form.php"><li>Register</li></a>
                </ul>
            </div>
        </div>
    </li></a>
            <a href="fund_transfer.php"><li>Transfert de fonds</li></a><br>
        </ul>
   
</div>

        <div id="aboutus" class="about"><span>About Us</span><br><br>
        <p>Les politiques économiques et sociales ne permettent pas toujours d’améliorer de manière significative les conditions de vie des populations à faibles revenus compte-tenu de leur difficulté à accéder aux ressources financières. Le Crédit Du Sahel fait ses preuves depuis plus de 20 ans à travers sa capacité à fournir des services financiers aux populations à faible revenus. Cette vision qui s’inscrit dans une démarche pérenne veille non seulement au respect du cadre juridique existant, mais aussi à une stratégie claire qui s’appuie sur une organisation transparente, efficace et acceptée par tous..</p>
    </div>
    
    <div class="disclaimer">
    <span>Disclaimer !!</spasn><br><br>
        <p>Notre banque ne vous demande pas les détails de votre compte/PIN/mot de passe. Par conséquent, toute personne prétendant vous demander des informations de la part de la banque ou de l'équipe technique peut être une entité frauduleuse, alors méfiez-vous.</p>
        <p>Vous devez savoir comment effectuer des transactions nettes et si vous ne le savez pas, vous pouvez vous abstenir de le faire. Vous pouvez demander conseil à la banque à cet égard. La Banque n'est pas responsable des erreurs de transactions en ligne.</p>
        <p>Nous ne sommes pas non plus responsables des transactions erronées et de la divulgation inconsidérée de détails par vous. L'option de visualisation et l'option de transaction sur le net sont différentes. Vous pouvez exercer votre option avec diligence.</p>
    </div>


    </div>
    
<?php include 'footer.php';?>
</body>

</html>